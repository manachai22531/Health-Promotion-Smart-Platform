(function(root,factory){if(typeof module==='object'&&module.exports)module.exports=factory();else root.CustomerDisplayModel=factory()})(typeof globalThis!=='undefined'?globalThis:this,function(){
 'use strict';
 const defaults={titleTh:'ข้อมูลการตรวจสุขภาพของฉัน',titleEn:'My health checkup',subtitleTh:'ดูแพ็กเกจและเลือกรายการตรวจเพิ่มเติมระหว่างรอเรียก',subtitleEn:'View packages and choose additional checkup services',identityTitleTh:'ยืนยันตัวตน',identityTitleEn:'Verify your identity',identityHintTh:'กรอกข้อมูลให้ตรงกับรายชื่อที่บริษัทส่งมา ระบบจะแสดงเฉพาะข้อมูลของคุณ',identityHintEn:'Enter the details registered by your company. Only your own information will be shown.',buttonTh:'ดูข้อมูลของฉัน',buttonEn:'View my information',helpTh:'',helpEn:'',supportPhone:'',supportUrl:'',primaryColor:'#075574',secondaryColor:'#07918b',backgroundColor:'#f1f9fc',defaultLanguage:'th',width:'standard',density:'comfortable',showLogo:true,showLanguageSwitch:true,showCardReader:true,showIdentityHelp:true,showSupport:false};
 const limits={titleTh:120,titleEn:120,subtitleTh:240,subtitleEn:240,identityTitleTh:80,identityTitleEn:80,identityHintTh:400,identityHintEn:400,buttonTh:60,buttonEn:60,helpTh:600,helpEn:600,supportPhone:40,supportUrl:500};
 function normalize(input){
  if(!input||typeof input!=='object'||Array.isArray(input))throw Error('รูปแบบการตั้งค่าไม่ถูกต้อง');
  const result={...defaults};
  for(const [key,value] of Object.entries(input)){
   if(!Object.hasOwn(defaults,key))throw Error('ไม่รองรับการตั้งค่า '+key);
   if(typeof defaults[key]==='boolean'){if(typeof value!=='boolean')throw Error('ค่าตัวเลือกไม่ถูกต้อง: '+key);result[key]=value;continue}
   if(typeof value!=='string')throw Error('ข้อความไม่ถูกต้อง: '+key);
   const text=value.trim();
   if(key.endsWith('Color')){if(!/^#[0-9a-f]{6}$/i.test(text))throw Error('สีต้องเป็นรหัส #RRGGBB');result[key]=text;continue}
   const options={defaultLanguage:['th','en'],width:['standard','wide'],density:['comfortable','compact']}[key];
   if(options){if(!options.includes(text))throw Error('ตัวเลือกไม่ถูกต้อง: '+key);result[key]=text;continue}
   if(text.length>limits[key])throw Error('ข้อความยาวเกินกำหนด: '+key);
   if(/^(title|identityTitle|button)/.test(key)&&!text)throw Error('กรุณาระบุข้อความ: '+key);
   result[key]=text;
  }
  if(result.supportPhone&&!/^[0-9+().\s-]+$/.test(result.supportPhone))throw Error('เบอร์ติดต่อไม่ถูกต้อง');
  if(result.supportUrl){let url;try{url=new URL(result.supportUrl)}catch{throw Error('ลิงก์ติดต่อไม่ถูกต้อง')}if(url.protocol!=='https:'||url.username||url.password)throw Error('ลิงก์ติดต่อต้องใช้ HTTPS และไม่มีรหัสผ่านใน URL');result.supportUrl=url.href}
  return result;
 }
 return {defaults,limits,normalize};
});
