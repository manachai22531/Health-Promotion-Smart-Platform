HealthCheck v7.64.68 — Production only
Target D:\HealthCheck\Production | Port 3000 | PGDATABASE health_check_smart_search
Read V7.64.68-README-TH.txt before installing. Existing custom credentials and data are preserved.
Role policies default to 90-day password age and 15-minute inactivity timeout.
