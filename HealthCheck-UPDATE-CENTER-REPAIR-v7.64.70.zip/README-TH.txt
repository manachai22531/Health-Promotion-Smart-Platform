﻿ตัวซ่อม Update Center สำหรับ HealthCheck v7.64.68/69

ใช้เมื่อแจ้ง Production health/version preflight failed จากการเรียก /api/system/health
1. รอให้ Update Center แสดง FAILED และไม่มีการอัปเดตกำลังทำงาน
2. แตกไฟล์ ZIP ทั้งหมดลงโฟลเดอร์ใหม่
3. เปิด REPAIR-UPDATE-CENTER.vbs และอนุญาต UAC
4. เมื่อแจ้งซ่อมสำเร็จ ให้กลับ Update Center อัปโหลด ZIP ตัวติดตั้ง v7.64.70 ใหม่
   ต้องอัปโหลด ZIP ใหม่เพราะสถานะ FAILED เดิมไม่ใช่แพ็กเกจที่พร้อมติดตั้ง
5. กดตรวจความพร้อมก่อนติดตั้ง แล้วดำเนินการเมื่อผ่านเท่านั้น

ซ่อมเฉพาะ D:\HealthCheck\Production\tools\app-update-helper.js
สำรอง helper เดิมใน D:\HealthCheck\Production\backups และตรวจ SHA256/JavaScript
ไม่หยุดแอป ไม่แก้ .env ไม่เปลี่ยนข้อมูลฐานข้อมูลหรือรีสตาร์ตบริการ
หากไม่ต้องการใช้ตัวซ่อม สามารถใช้ INSTALL-REPAIR.vbs จากตัวติดตั้งเต็ม v7.64.70 แทน
ไฟล์ซ่อมนี้ไม่ใช่ Update Package ห้ามนำ ZIP ตัวซ่อมไปอัปโหลดใน Update Center

ทดสอบฟังก์ชันซ่อมไฟล์และ PowerShell syntax บน Linux
ยังไม่ได้รัน VBS, UAC หรือ Windows GUI จริง
