/* Fictional, local-only preview. Deliberately has no customer API or session access. */
var customerLang='th',pendingCustomerSelectionDraft=null,customerPortalProfile=null;
var esc=value=>String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
var renderCustomerProfile=function(){},updateCustomerSelectionTotal=function(){},customerPortalLogout=async function(){};
var applyCustomerLanguage=function(lang){customerLang=lang;document.documentElement.lang=lang;document.querySelectorAll('[data-lang]').forEach(b=>b.classList.toggle('active',b.dataset.lang===lang));};
(()=>{'use strict';
 const model=window.CustomerDisplayModel;let settings=model.normalize(model.defaults);
 try{settings=model.normalize(JSON.parse(decodeURIComponent(location.hash.slice(1))))}catch{}
 history.replaceState(null,'',location.pathname);customerLang=settings.defaultLanguage;
 const root=document.getElementById('customerPortalScreen');
 for(const [key,css] of [['primaryColor','--cd-primary'],['secondaryColor','--cd-secondary'],['backgroundColor','--cd-background']])root.style.setProperty(css,settings[key]);
 root.classList.toggle('cd-wide',settings.width==='wide');root.classList.toggle('cd-compact',settings.density==='compact');
 document.querySelector('.customer-portal-head img').hidden=!settings.showLogo;document.querySelector('.customer-language').hidden=!settings.showLanguageSwitch;
 const ads=document.createElement('div');ads.className='cd-advertising';ads.innerHTML=model.advertisementMarkup(settings,customerLang);document.querySelector('.customer-portal-head').after(ads);
 const records=[['CBC','Complete Blood Count (CBC)','LAB','เลือด',250],['GLU','Fasting Blood Sugar','LAB','เบาหวาน',120],['LIPID','Lipid Profile','LAB','ไขมัน',550],['CT-CAL','CT Calcium Scoring','X-Ray & Imaging','CT Scan',2200],['CXR','Chest X-Ray','X-Ray & Imaging','เอกซเรย์',450],['US-ABD','Ultrasound Whole Abdomen','Ultrasound','ช่องท้อง',1800],['EKG','Electrocardiogram','Cardio','คลื่นไฟฟ้าหัวใจ',500],['FLU','Influenza Vaccine','Vaccine','วัคซีน',750]];
 const names={LAB:'ห้องปฏิบัติการ','X-Ray & Imaging':'เอกซเรย์ / ภาพวินิจฉัย',Ultrasound:'อัลตราซาวด์',Cardio:'หัวใจ',Vaccine:'วัคซีน'};
 const item=(row,index)=>({id:'demo-'+index,code:row[0],name:row[1],category:row[2],categoryName:names[row[2]],subcategory:row[3],price:row[4],priced:true,description:'ข้อมูลสมมติสำหรับทดลองแสดงผล รายการตรวจและราคาใช้เป็นตัวอย่างเท่านั้น'});
 customerPortalProfile={locked:false,choices:{contract:records.map(item),billing:records.slice(0,2).map(item),cash:records.slice(5).map(item)}};
 document.getElementById('customerSelectionForm').onsubmit=event=>{event.preventDefault();const status=document.getElementById('customerSelectionStatus');status.textContent=customerLang==='en'?'Preview only — no order was submitted.':'ทดลองตรวจสอบรายการแล้ว · ไม่มีการบันทึกหรือส่งคำสั่งซื้อจริง';};
 window.startCustomerShopPreview=()=>{renderCustomerProfile(customerPortalProfile);window.HealthCheckCustomerKnowledge?.paint(root,settings);applyCustomerLanguage(customerLang);document.querySelectorAll('[data-lang]').forEach(b=>b.onclick=()=>applyCustomerLanguage(b.dataset.lang));};
})();
