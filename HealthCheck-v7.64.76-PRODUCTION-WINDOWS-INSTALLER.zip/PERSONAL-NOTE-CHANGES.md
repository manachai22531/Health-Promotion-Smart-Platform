# Personal notes — included in v7.64.76

Per-person company/year notes appear under sales contact in search and in the left part of the service overview totals block. Authorized users can save through the dedicated note action or Save All. The scoped endpoint checks concurrent edits, audits updates, maintains relational sync and preserves compact app_state storage. Read-only roles cannot edit.

Customer Excel templates, parser, preview, View All Company/Booking tables and exports share the same note field. Empty/missing note columns preserve saved notes on reimport; instruction columns are excluded. Imported changes record the authenticated actor. Existing column preferences gain the new column once and retain subsequent hide/show choices.

Actual PostgreSQL/Chromium verification covers save/reload, isolation, import/empty/conflict validation, escaped text, Save All, responsive layout and restart persistence. This source includes all earlier customer appointment, health-book, company, security and installer work.
